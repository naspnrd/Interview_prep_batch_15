# 1
class Node:
    #constructor
    def __init__(self, data):
        self.data = data
        self.next = None

first = Node(5) # this create me a node with value 5 
                # and node name is first

# print ie accessing node first

print(first.data) # print 5
print(first.next) # print None
print(first) # print address of node

#create few  more nodes
second = Node(10)
third = Node(15)
fourth = Node(20)
print(second)
print(third)

#Linking
first.next = second
second.next = third
third.next = fourth
head = first
print(head)

#traversing the Linked List
def printLinkedList():
    #temporary variable
    curr = head
    # while(curr is not None):
    while(curr):
        print(curr.data)
        curr = curr.next #increating the current pointer
printLinkedList()