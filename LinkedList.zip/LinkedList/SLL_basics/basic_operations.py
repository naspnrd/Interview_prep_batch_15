# 1. Insertion at beginning

class Node:
    #constructor
    def __init__(self, data):
        self.data = data
        self.next = None

def insertAtBeginning(data):
    global head
    newNode = Node(data) #node is created
    #node we have to insert newNode at beginning
    newNode.next = head
    head = newNode
    return head

#to add node at last
def insertAtEnd(data):
    global head
    newNode = Node(data)
    curr = head
    while(curr.next is not None):
        curr = curr.next
    #now we are at last node , so we will attach to the last node
    curr.next = newNode

#deletion at beginning
def deleteAtBeginning():
    global head
    if(head is not None):
        head = head.next
def deleteAtEnd():
    global head
    if(head is None or head.next is None):
        return None
    curr = head
    while(curr.next.next is not None):
        curr = curr.next
    curr.next = None
    return head

def printLinkedList():
    #temporary variable
    curr = head
    # while(curr is not None):
    # #these all condition will come when you ask alternate question
    # while(curr):
    #     print(curr.data),
    #     #this needed because if curr.next is not none then only 
    #     #we will move forward otherwise just break out of the loop
    #     if(curr.next):
    #         curr = curr.next.next #increating the current pointer
    #     else:
    #         break
    while(curr):
        print(curr.data),
        curr = curr.next

head = None
head = insertAtBeginning(0)
head = insertAtBeginning(5)
head = insertAtBeginning(10)
head = insertAtBeginning(15)
head = insertAtBeginning(20)
# printLinkedList()
# insertAtEnd(0)
# print(" ")
printLinkedList()

# deleteAtBeginning()
# print(" ")
# printLinkedList()

# deleteAtBeginning()
# print(" ")
# printLinkedList()

# head = deleteAtEnd()
# print(" ")
# printLinkedList()

